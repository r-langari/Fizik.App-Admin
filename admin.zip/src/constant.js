export const INCREASE_CAT = 'INCREASE_CAT';
